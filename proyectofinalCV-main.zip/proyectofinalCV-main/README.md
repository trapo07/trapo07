# proyectofinalCV #argentina-programa-4.0
Proyecto Final CV. Lucia Perez Alberca

Armado de Curriculum con Visual Studio Code, utlizando HTML, CSS y JS.
programa Argentina Programa 4.0
Academia Ticmas, "Primeros pasos del Desarrollo Front End"

Proyecto finalizado el 05-01-2023.
